<?
	define("MADEREQUEST", "<p style='color:#00b722'>Запрос на сервер Битрикса выполнен, данные получены.</p>");
	define("KEYNOTCHANGE", "<p style='color:#00b722'>Ключ не изменился с предыдущего запроса, выведенны старые данные сохраненые в сесии.</p>");
	define("SHORTKEY", "<p style='color:#ff9696'>Ключ короче чем должен быть.</p>");
	define("UNKNOWNERROR", "Неизвестная ошибка.");
	
?>